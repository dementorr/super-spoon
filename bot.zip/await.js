module.exports.run = async (bot, message, args) => {
	throw new Error ("hi");
}

module.exports.help = {
	name: "await"
}